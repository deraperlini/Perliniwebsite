"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <>
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-[#0D1929]/95 backdrop-blur-md border-b border-[rgba(212,175,111,0.15)]"
            : "bg-transparent"
        }`}
        role="navigation"
        aria-label="Main navigation"
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-16 flex items-center justify-between">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="font-serif text-[#D4AF6F] text-lg tracking-[0.12em] uppercase hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F] focus-visible:ring-offset-1 focus-visible:ring-offset-[#0D1929]"
            aria-label="Perlini Consulting — scroll to top"
          >
            Perlini
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {[
              { label: "About", id: "about" },
              { label: "The Guide", id: "what-youll-get" },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="text-[#C5BCA8] hover:text-[#F5F0E6] text-sm tracking-[0.08em] uppercase transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => scrollTo("waitlist")}
              className="ml-4 px-5 py-2 border border-[rgba(212,175,111,0.5)] text-[#D4AF6F] text-sm tracking-[0.1em] uppercase hover:bg-[rgba(212,175,111,0.08)] transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
            >
              Join Waitlist
            </button>
          </div>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden flex flex-col gap-1.5 p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
          >
            <span
              className={`block w-6 h-px bg-[#D4AF6F] transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2.5" : ""}`}
            />
            <span
              className={`block w-6 h-px bg-[#D4AF6F] transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`}
            />
            <span
              className={`block w-6 h-px bg-[#D4AF6F] transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2.5" : ""}`}
            />
          </button>
        </div>
      </motion.nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="fixed top-16 left-0 right-0 z-40 bg-[#0D1929]/98 backdrop-blur-md border-b border-[rgba(212,175,111,0.15)] md:hidden"
            role="menu"
          >
            <div className="flex flex-col px-6 py-6 gap-6">
              {[
                { label: "About Dera", id: "about" },
                { label: "The Guide", id: "what-youll-get" },
                { label: "Why I Built This", id: "why" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollTo(item.id)}
                  className="text-left text-[#C5BCA8] hover:text-[#F5F0E6] text-base tracking-[0.06em] uppercase transition-colors"
                  role="menuitem"
                >
                  {item.label}
                </button>
              ))}
              <button
                onClick={() => scrollTo("waitlist")}
                className="mt-2 px-5 py-3 border border-[rgba(212,175,111,0.5)] text-[#D4AF6F] text-sm tracking-[0.1em] uppercase hover:bg-[rgba(212,175,111,0.08)] transition-all text-left"
                role="menuitem"
              >
                Join Waitlist →
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
