"use client";

import { motion } from "framer-motion";
import { Calendar } from "lucide-react";

export default function Hero() {
  const scrollToWaitlist = () => {
    const el = document.getElementById("waitlist");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden"
      aria-label="Hero — Perlini Consulting"
    >
      {/* Background: Earth at night */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/earth-night.jpg')`,
        }}
        role="img"
        aria-label="Earth at night from space showing city lights across Europe"
      />

      {/* Deep overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0D1929]/70 via-[#0D1929]/55 to-[#0D1929]/85" />
      <div className="absolute inset-0 bg-[#0D1929]/35" />

      {/* Star field overlay */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          backgroundImage: `radial-gradient(1px 1px at 10% 15%, rgba(245,240,230,0.8) 0%, transparent 100%),
            radial-gradient(1px 1px at 25% 8%, rgba(245,240,230,0.5) 0%, transparent 100%),
            radial-gradient(1px 1px at 40% 22%, rgba(245,240,230,0.7) 0%, transparent 100%),
            radial-gradient(1px 1px at 60% 5%, rgba(245,240,230,0.6) 0%, transparent 100%),
            radial-gradient(1px 1px at 75% 18%, rgba(245,240,230,0.8) 0%, transparent 100%),
            radial-gradient(1px 1px at 88% 10%, rgba(245,240,230,0.4) 0%, transparent 100%),
            radial-gradient(1px 1px at 15% 35%, rgba(245,240,230,0.5) 0%, transparent 100%),
            radial-gradient(1px 1px at 92% 30%, rgba(245,240,230,0.7) 0%, transparent 100%)`,
        }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 text-center px-6 md:px-12 max-w-4xl mx-auto">
        {/* Brand name */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.1 }}
        >
          <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.35em] uppercase mb-4">
            Perlini Consulting
          </p>
        </motion.div>

        {/* Gold divider */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
          className="mx-auto mb-8"
          style={{
            width: "50px",
            height: "1px",
            background: "linear-gradient(90deg, transparent, #D4AF6F, transparent)",
          }}
          aria-hidden="true"
        />

        {/* Main headline */}
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: "easeOut", delay: 0.4 }}
          className="font-serif text-4xl md:text-6xl lg:text-7xl leading-[1.1] tracking-[-0.02em] mb-6"
        >
          <span className="text-[#F5F0E6] block">The Insider Roadmap</span>
          <span className="text-[#D4AF6F] block italic">I Wish I Had at 20</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.6 }}
          className="font-sans text-[#F5F0E6] text-lg md:text-xl font-light leading-relaxed mb-4 max-w-2xl mx-auto"
        >
          Break into diplomacy, EU institutions, embassies, and international organizations.
        </motion.p>

        {/* Supporting copy */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.75 }}
          className="font-sans text-[#C5BCA8] text-base md:text-lg font-light leading-relaxed mb-12 max-w-xl mx-auto"
        >
          Written from inside a German embassy and informed by conversations with diplomats,
          officials, and applicants across the field.
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.9 }}
          className="flex flex-col items-center gap-5"
        >
          <button
            onClick={scrollToWaitlist}
            className="group inline-flex items-center gap-3 px-8 py-4 bg-[#D4AF6F] text-[#0D1929] font-sans text-sm font-semibold tracking-[0.15em] uppercase hover:bg-[#C89D54] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(212,175,111,0.25)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0D1929]"
            aria-label="Join Early Access waitlist"
          >
            Join Early Access
            <span
              className="inline-block transition-transform duration-200 group-hover:translate-x-1"
              aria-hidden="true"
            >
              →
            </span>
          </button>

          <div className="flex items-center gap-2 text-[#C5BCA8] text-sm font-light">
            <Calendar size={14} className="text-[#D4AF6F]" aria-hidden="true" />
            <span>Launching Summer 2026</span>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        aria-hidden="true"
      >
        <div className="w-px h-12 bg-gradient-to-b from-transparent via-[rgba(212,175,111,0.5)] to-transparent animate-pulse" />
      </motion.div>
    </section>
  );
}
