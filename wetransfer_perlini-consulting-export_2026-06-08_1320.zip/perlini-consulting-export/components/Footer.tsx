"use client";

import { Linkedin, Instagram, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer
      className="py-12 md:py-14 px-6 md:px-12"
      style={{ borderTop: "1px solid rgba(212,175,111,0.12)" }}
      role="contentinfo"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="text-center md:text-left">
            <p className="font-serif text-[#D4AF6F] text-base tracking-[0.12em] uppercase mb-1">
              Perlini Consulting
            </p>
            <p className="font-sans text-[#C5BCA8]/60 text-xs tracking-[0.06em]">
              © 2026 Perlini Consulting. All rights reserved.
            </p>
          </div>

          {/* Nav links */}
          <nav aria-label="Footer navigation">
            <ul className="flex items-center gap-6 md:gap-8">
              <li>
                <a
                  href="https://www.linkedin.com/in/deraperlini"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-1.5 font-sans text-[#C5BCA8] hover:text-[#D4AF6F] text-sm tracking-[0.06em] uppercase transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                  aria-label="LinkedIn"
                >
                  <Linkedin size={14} strokeWidth={1.5} aria-hidden="true" />
                  <span className="hidden sm:inline">LinkedIn</span>
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/deraperlini"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-1.5 font-sans text-[#C5BCA8] hover:text-[#D4AF6F] text-sm tracking-[0.06em] uppercase transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                  aria-label="Instagram"
                >
                  <Instagram size={14} strokeWidth={1.5} aria-hidden="true" />
                  <span className="hidden sm:inline">Instagram</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@perlini.consulting"
                  className="group flex items-center gap-1.5 font-sans text-[#C5BCA8] hover:text-[#D4AF6F] text-sm tracking-[0.06em] uppercase transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                  aria-label="Contact via email"
                >
                  <Mail size={14} strokeWidth={1.5} aria-hidden="true" />
                  <span className="hidden sm:inline">Contact</span>
                </a>
              </li>
              <li>
                <a
                  href="/privacy"
                  className="font-sans text-[#C5BCA8] hover:text-[#D4AF6F] text-sm tracking-[0.06em] uppercase transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                >
                  Privacy
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </footer>
  );
}
