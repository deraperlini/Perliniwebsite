"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Check } from "lucide-react";

const stats = [
  { number: "3K+", label: "Questions Answered" },
  { number: "75+", label: "Institutions Mapped" },
  { number: "25+", label: "Countries Represented" },
  { number: "1", label: "Mission" },
];

const questions = [
  "How do I get into the EU?",
  "How do I get into the UN?",
  "Which master's programs actually matter?",
  "How do I position myself?",
  "What opportunities am I missing?",
];

export default function WhyBuilding() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="why"
      ref={ref}
      className="py-28 md:py-36 px-6 md:px-12"
      aria-labelledby="why-heading"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 md:gap-24 items-start">
          {/* Left column */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.3em] uppercase mb-4">
              The Origin
            </p>
            <h2
              id="why-heading"
              className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#F5F0E6] leading-[1.15] mb-8"
            >
              Why I&apos;m Building This
            </h2>
            <div
              className="w-12 h-px bg-[#D4AF6F] mb-10"
              aria-hidden="true"
            />

            <p className="font-sans text-[#C5BCA8] text-base leading-relaxed mb-10">
              When I started my journey into international affairs, I had the same questions
              everyone asks — but nobody was giving real answers. Not the kind you actually need.
            </p>

            <ul className="space-y-4 mb-12" role="list" aria-label="Common questions I answer">
              {questions.map((question, i) => (
                <motion.li
                  key={question}
                  initial={{ opacity: 0, x: -16 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 + i * 0.08 }}
                  className="flex items-start gap-3"
                >
                  <span
                    className="flex-shrink-0 w-5 h-5 rounded-full border border-[rgba(212,175,111,0.5)] flex items-center justify-center mt-0.5"
                    aria-hidden="true"
                  >
                    <Check size={11} className="text-[#D4AF6F]" />
                  </span>
                  <span className="font-sans text-[#F5F0E6] text-base">{question}</span>
                </motion.li>
              ))}
            </ul>

            <motion.blockquote
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="border-l-2 border-[#D4AF6F] pl-5 py-1"
            >
              <p className="font-serif text-[#F5F0E6] text-lg italic leading-relaxed">
                &ldquo;I&apos;m creating the resource I wish I had when I started.&rdquo;
              </p>
              <footer className="mt-2 font-sans text-[#C5BCA8] text-sm">— Dera Perlini</footer>
            </motion.blockquote>
          </motion.div>

          {/* Right column — stat cards */}
          <div className="grid grid-cols-2 gap-4" role="list" aria-label="Key statistics">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                role="listitem"
                initial={{ opacity: 0, y: 24 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.7, ease: "easeOut", delay: 0.2 + i * 0.12 }}
                className="group p-7 border border-[rgba(212,175,111,0.18)] bg-[#15263D]/60 hover:border-[rgba(212,175,111,0.45)] hover:bg-[#15263D]/90 transition-all duration-300 cursor-default"
                style={{
                  backdropFilter: "blur(4px)",
                }}
              >
                <div
                  className="font-serif text-4xl md:text-5xl text-[#D4AF6F] mb-2 leading-none group-hover:text-[#C89D54] transition-colors duration-300"
                  aria-label={stat.number}
                >
                  {stat.number}
                </div>
                <div className="font-sans text-[#C5BCA8] text-sm tracking-[0.06em] uppercase leading-snug group-hover:text-[#F5F0E6] transition-colors duration-300">
                  {stat.label}
                </div>
                <div
                  className="mt-4 w-6 h-px bg-[rgba(212,175,111,0.3)] group-hover:bg-[rgba(212,175,111,0.6)] transition-all duration-300 group-hover:w-10"
                  aria-hidden="true"
                />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
