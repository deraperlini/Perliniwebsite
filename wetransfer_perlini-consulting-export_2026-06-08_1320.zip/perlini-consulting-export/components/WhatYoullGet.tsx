"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  Building2,
  Globe,
  Users,
  Sparkles,
  GraduationCap,
  UserCheck,
  Network,
  CalendarDays,
} from "lucide-react";

const features = [
  {
    icon: Building2,
    title: "Embassy Career Pathways",
    description:
      "How diplomatic missions hire, what roles exist, and how to position yourself as a competitive candidate.",
  },
  {
    icon: Globe,
    title: "EU Institutions Explained",
    description:
      "The Commission, Parliament, Council, EEAS — their structures, entry routes, and what selection panels look for.",
  },
  {
    icon: Users,
    title: "UN Opportunities Decoded",
    description:
      "JPO programmes, internships, roster competitions, and how the UN hiring ecosystem actually functions.",
  },
  {
    icon: Sparkles,
    title: "Hidden Agencies & Fellowships",
    description:
      "Lesser-known international bodies, bilateral programmes, and fellowship schemes most applicants never discover.",
  },
  {
    icon: GraduationCap,
    title: "Master's Strategy Framework",
    description:
      "Which programmes genuinely open doors, how to evaluate them, and how to leverage your degree strategically.",
  },
  {
    icon: UserCheck,
    title: "Building Your Profile",
    description:
      "How to construct a competitive application profile across experience, language, and positioning over time.",
  },
  {
    icon: Network,
    title: "Networking Playbook",
    description:
      "How to build genuine relationships in international affairs without feeling transactional or ineffective.",
  },
  {
    icon: CalendarDays,
    title: "12-Month Action Plan",
    description:
      "A sequenced, practical roadmap from where you are now to your first professional role in the field.",
  },
];

export default function WhatYoullGet() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });

  return (
    <section
      id="what-youll-get"
      ref={ref}
      className="py-28 md:py-36 px-6 md:px-12 bg-[#15263D]/40"
      style={{
        borderTop: "1px solid rgba(212,175,111,0.1)",
        borderBottom: "1px solid rgba(212,175,111,0.1)",
      }}
      aria-labelledby="guide-heading"
    >
      <div className="max-w-7xl mx-auto">
        {/* Heading block */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center mb-16 md:mb-20"
        >
          <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.3em] uppercase mb-4">
            The Diplomacy Guide
          </p>
          <h2
            id="guide-heading"
            className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#F5F0E6] leading-[1.15] max-w-2xl mx-auto"
          >
            What You&apos;ll Get
          </h2>
          <div className="w-12 h-px bg-[#D4AF6F] mx-auto mt-6" aria-hidden="true" />
          <p className="font-sans text-[#C5BCA8] text-lg font-light leading-relaxed max-w-xl mx-auto mt-6">
            Eight comprehensive chapters giving you the complete picture — from first steps to
            first role.
          </p>
        </motion.div>

        {/* Feature grid */}
        <div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5"
          role="list"
          aria-label="Guide chapters"
        >
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <motion.article
                key={feature.title}
                role="listitem"
                initial={{ opacity: 0, y: 24 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, ease: "easeOut", delay: i * 0.07 }}
                className="group p-6 border border-[rgba(212,175,111,0.15)] hover:border-[rgba(212,175,111,0.4)] bg-[#0D1929]/60 hover:bg-[#15263D]/80 transition-all duration-300"
              >
                <div className="mb-5">
                  <Icon
                    size={22}
                    className="text-[#D4AF6F] group-hover:text-[#C89D54] transition-colors duration-300"
                    strokeWidth={1.5}
                    aria-hidden="true"
                  />
                </div>
                <h3 className="font-serif text-[#F5F0E6] text-lg leading-snug mb-3 group-hover:text-[#D4AF6F] transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="font-sans text-[#C5BCA8] text-sm leading-relaxed">
                  {feature.description}
                </p>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
