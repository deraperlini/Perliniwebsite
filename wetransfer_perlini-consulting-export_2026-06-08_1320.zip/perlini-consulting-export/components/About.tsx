"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import Image from "next/image";
import { Linkedin, Instagram, Mail } from "lucide-react";

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="about"
      ref={ref}
      className="py-28 md:py-36 px-6 md:px-12"
      aria-labelledby="about-heading"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 md:gap-24 items-center">
          {/* Left: Image */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, ease: "easeOut" }}
            className="relative order-2 md:order-1"
          >
            <div
              className="relative overflow-hidden"
              style={{
                borderRadius: "2px",
                border: "1px solid rgba(212,175,111,0.3)",
              }}
            >
              {/* Replace /public/dera-perlini.jpg with a real photo of Dera Perlini */}
              <Image
                src="/dera-perlini.jpg"
                alt="Dera Perlini — Founder of Perlini Consulting, international affairs professional and former diplomat at the German Embassy in Abu Dhabi"
                width={600}
                height={750}
                className="w-full h-auto object-cover"
                priority={false}
                placeholder="blur"
                blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAAIAAoDASIAAhEBAxEB/8QAFgABAQEAAAAAAAAAAAAAAAAABQME/8QAIhAAAQMEAgMAAAAAAAAAAAAAAQIDBAUREiExQf/EABUBAQEAAAAAAAAAAAAAAAAAAAED/8QAFhEBAQEAAAAAAAAAAAAAAAAAAAAR/9oADAMBAAIRAxEAPwCyzpjWYJuZk3BfJeYbDTTfA5SJHQBU3EknuVJO+gDuTTsjSqlqjuWyOi2WiUJcJRkADYn9HSSdySST6rjSSWSQVBf/2Q=="
              />
            </div>
            {/* Decorative gold offset border */}
            <div
              className="absolute -bottom-4 -right-4 w-full h-full border border-[rgba(212,175,111,0.15)] -z-10 hidden md:block"
              style={{ borderRadius: "2px" }}
              aria-hidden="true"
            />
          </motion.div>

          {/* Right: Content */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, ease: "easeOut", delay: 0.15 }}
            className="order-1 md:order-2"
          >
            <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.3em] uppercase mb-4">
              The Founder
            </p>
            <h2
              id="about-heading"
              className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#F5F0E6] leading-[1.15] mb-6"
            >
              About Dera Perlini
            </h2>
            <div className="w-12 h-px bg-[#D4AF6F] mb-8" aria-hidden="true" />

            <div className="space-y-5">
              <p className="font-sans text-[#C5BCA8] text-base leading-[1.85]">
                I studied International Affairs and was selected for a diplomatic internship at the{" "}
                <strong className="text-[#F5F0E6] font-medium">German Embassy in Abu Dhabi</strong>.
              </p>
              <p className="font-sans text-[#C5BCA8] text-base leading-[1.85]">
                Through sharing my journey on Instagram, I built a community of{" "}
                <strong className="text-[#F5F0E6] font-medium">
                  35,000+ aspiring diplomats
                </strong>{" "}
                and international professionals from over 25 countries.
              </p>
              <p className="font-sans text-[#C5BCA8] text-base leading-[1.85]">
                I created Perlini Consulting to give the next generation what I wish I had: an{" "}
                <em className="text-[#F5F0E6] font-light italic">insider roadmap</em>, not generic
                advice.
              </p>
            </div>

            {/* Social links */}
            <div className="flex items-center gap-4 mt-10">
              <a
                href="https://www.linkedin.com/in/deraperlini"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 px-4 py-2 border border-[rgba(212,175,111,0.3)] text-[#C5BCA8] hover:border-[#D4AF6F] hover:text-[#D4AF6F] transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                aria-label="Connect with Dera Perlini on LinkedIn"
              >
                <Linkedin
                  size={16}
                  strokeWidth={1.5}
                  className="group-hover:text-[#D4AF6F] transition-colors"
                  aria-hidden="true"
                />
                <span className="text-sm tracking-[0.06em] uppercase">LinkedIn</span>
              </a>

              <a
                href="https://www.instagram.com/deraperlini"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 px-4 py-2 border border-[rgba(212,175,111,0.3)] text-[#C5BCA8] hover:border-[#D4AF6F] hover:text-[#D4AF6F] transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                aria-label="Follow Dera Perlini on Instagram"
              >
                <Instagram
                  size={16}
                  strokeWidth={1.5}
                  className="group-hover:text-[#D4AF6F] transition-colors"
                  aria-hidden="true"
                />
                <span className="text-sm tracking-[0.06em] uppercase">Instagram</span>
              </a>

              <a
                href="mailto:hello@perlini.consulting"
                className="group flex items-center gap-2 px-4 py-2 border border-[rgba(212,175,111,0.3)] text-[#C5BCA8] hover:border-[#D4AF6F] hover:text-[#D4AF6F] transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
                aria-label="Email Dera Perlini"
              >
                <Mail
                  size={16}
                  strokeWidth={1.5}
                  className="group-hover:text-[#D4AF6F] transition-colors"
                  aria-hidden="true"
                />
                <span className="text-sm tracking-[0.06em] uppercase">Email</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
