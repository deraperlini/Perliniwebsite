"use client";

import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { ArrowRight, Loader2 } from "lucide-react";
import { trackWaitlistSignup } from "@/lib/analytics";

export default function Waitlist() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || status === "loading") return;

    setStatus("loading");
    setErrorMsg("");

    try {
      const response = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Something went wrong");
      }

      trackWaitlistSignup(email);
      setStatus("success");
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Failed to subscribe. Please try again.");
      setStatus("error");
    }
  };

  return (
    <section
      id="waitlist"
      ref={ref}
      className="py-28 md:py-36 px-6 md:px-12 bg-[#15263D]/30"
      style={{ borderTop: "1px solid rgba(212,175,111,0.1)" }}
      aria-labelledby="waitlist-heading"
    >
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative p-10 md:p-14"
          style={{
            border: "1px solid rgba(212,175,111,0.35)",
            background:
              "linear-gradient(135deg, rgba(21,38,61,0.8) 0%, rgba(13,25,41,0.9) 100%)",
          }}
        >
          {/* Corner accents */}
          <div
            className="absolute top-0 left-0 w-6 h-6 border-t border-l border-[#D4AF6F]"
            aria-hidden="true"
          />
          <div
            className="absolute top-0 right-0 w-6 h-6 border-t border-r border-[#D4AF6F]"
            aria-hidden="true"
          />
          <div
            className="absolute bottom-0 left-0 w-6 h-6 border-b border-l border-[#D4AF6F]"
            aria-hidden="true"
          />
          <div
            className="absolute bottom-0 right-0 w-6 h-6 border-b border-r border-[#D4AF6F]"
            aria-hidden="true"
          />

          <div className="text-center mb-10">
            <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.3em] uppercase mb-4">
              Early Access
            </p>
            <h2
              id="waitlist-heading"
              className="font-serif text-3xl md:text-4xl lg:text-5xl text-[#F5F0E6] leading-[1.15] mb-5"
            >
              Join the Waitlist
            </h2>
            <div className="w-12 h-px bg-[#D4AF6F] mx-auto mb-6" aria-hidden="true" />
            <p className="font-sans text-[#C5BCA8] text-base md:text-lg leading-relaxed max-w-lg mx-auto">
              Be first to receive updates, early-bird pricing, and exclusive bonus content.
            </p>
          </div>

          {status === "success" ? (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center py-6"
              role="alert"
              aria-live="polite"
            >
              <div className="inline-flex items-center justify-center w-12 h-12 border border-[rgba(212,175,111,0.4)] mb-5">
                <span className="text-[#D4AF6F] text-xl" aria-hidden="true">✓</span>
              </div>
              <p className="font-serif text-[#F5F0E6] text-xl md:text-2xl italic leading-relaxed max-w-md mx-auto">
                You&apos;re in. Watch your inbox — I&apos;ll send the first insider note in a few
                days.
              </p>
              <p className="font-sans text-[#C5BCA8] text-sm mt-4">— Dera</p>
            </motion.div>
          ) : (
            <form
              onSubmit={handleSubmit}
              noValidate
              aria-label="Join the Diplomacy Guide waitlist"
              className="flex flex-col md:flex-row gap-3"
            >
              <div className="flex-1">
                <label htmlFor="waitlist-email" className="sr-only">
                  Email address
                </label>
                <input
                  id="waitlist-email"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (status === "error") setStatus("idle");
                  }}
                  placeholder="Your email address"
                  required
                  autoComplete="email"
                  disabled={status === "loading"}
                  aria-describedby={status === "error" ? "waitlist-error" : undefined}
                  aria-invalid={status === "error"}
                  className="w-full px-5 py-4 bg-[#0D1929]/80 border border-[rgba(212,175,111,0.25)] text-[#F5F0E6] placeholder:text-[#C5BCA8]/60 focus:outline-none focus:border-[rgba(212,175,111,0.7)] focus:ring-1 focus:ring-[rgba(212,175,111,0.3)] transition-all duration-200 text-base disabled:opacity-60"
                  style={{ borderRadius: 0 }}
                />
              </div>

              <button
                type="submit"
                disabled={status === "loading" || !email}
                className="group flex items-center justify-center gap-3 px-8 py-4 bg-[#D4AF6F] text-[#0D1929] font-sans text-sm font-semibold tracking-[0.12em] uppercase hover:bg-[#C89D54] transition-all duration-200 hover:-translate-y-0.5 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F] focus-visible:ring-offset-2 focus-visible:ring-offset-[#0D1929] whitespace-nowrap"
                style={{ borderRadius: 0 }}
                aria-label="Subscribe to the waitlist"
              >
                {status === "loading" ? (
                  <>
                    <Loader2 size={16} className="animate-spin" aria-hidden="true" />
                    <span>Joining...</span>
                  </>
                ) : (
                  <>
                    <span>Join Now</span>
                    <ArrowRight
                      size={16}
                      className="group-hover:translate-x-0.5 transition-transform duration-200"
                      aria-hidden="true"
                    />
                  </>
                )}
              </button>
            </form>
          )}

          {status === "error" && errorMsg && (
            <motion.p
              id="waitlist-error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              role="alert"
              aria-live="polite"
              className="mt-3 font-sans text-sm text-red-400 text-center"
            >
              {errorMsg}
            </motion.p>
          )}

          {status !== "success" && (
            <p className="font-sans text-[#C5BCA8]/60 text-xs text-center mt-5 tracking-[0.04em]">
              No spam. Unsubscribe at any time.
            </p>
          )}
        </motion.div>
      </div>
    </section>
  );
}
