// Analytics utility for GA4 and Meta Pixel

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    fbq?: (...args: unknown[]) => void;
    dataLayer?: unknown[];
  }
}

export const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID || "";
export const META_PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID || "";

export function trackEvent(eventName: string, params?: Record<string, unknown>) {
  // GA4
  if (typeof window !== "undefined" && window.gtag && GA_MEASUREMENT_ID) {
    window.gtag("event", eventName, params);
  }
  // Meta Pixel
  if (typeof window !== "undefined" && window.fbq && META_PIXEL_ID) {
    window.fbq("track", eventName === "waitlist_signup" ? "Lead" : eventName, params);
  }
}

export function trackWaitlistSignup(email?: string) {
  trackEvent("waitlist_signup", {
    event_category: "engagement",
    event_label: "diplomacy_guide_waitlist",
    email_domain: email ? email.split("@")[1] : undefined,
  });
}
