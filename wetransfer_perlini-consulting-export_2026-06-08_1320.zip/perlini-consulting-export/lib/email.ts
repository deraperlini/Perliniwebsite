// Email provider adapter architecture
// Supports ConvertKit, MailerLite, and Mailchimp

export type EmailProvider = "convertkit" | "mailerlite" | "mailchimp";

interface SubscribeResult {
  success: boolean;
  message: string;
}

async function subscribeConvertKit(email: string): Promise<SubscribeResult> {
  const apiKey = process.env.CONVERTKIT_API_KEY;
  const formId = process.env.CONVERTKIT_FORM_ID;

  if (!apiKey || !formId) {
    throw new Error("ConvertKit API key or form ID not configured");
  }

  const response = await fetch(
    `https://api.convertkit.com/v3/forms/${formId}/subscribe`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        email,
        tags: ["Perlini Waitlist"],
      }),
    }
  );

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || "ConvertKit subscription failed");
  }

  return { success: true, message: "Subscribed via ConvertKit" };
}

async function subscribeMailerLite(email: string): Promise<SubscribeResult> {
  const apiKey = process.env.MAILERLITE_API_KEY;
  const groupId = process.env.MAILERLITE_GROUP_ID;

  if (!apiKey) {
    throw new Error("MailerLite API key not configured");
  }

  const body: Record<string, unknown> = { email, groups: groupId ? [groupId] : [] };

  const response = await fetch("https://connect.mailerlite.com/api/subscribers", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok && response.status !== 200 && response.status !== 201) {
    const error = await response.json();
    throw new Error(error.message || "MailerLite subscription failed");
  }

  return { success: true, message: "Subscribed via MailerLite" };
}

async function subscribeMailchimp(email: string): Promise<SubscribeResult> {
  const apiKey = process.env.MAILCHIMP_API_KEY;
  const listId = process.env.MAILCHIMP_LIST_ID;
  const serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX || "us1";

  if (!apiKey || !listId) {
    throw new Error("Mailchimp API key or list ID not configured");
  }

  const response = await fetch(
    `https://${serverPrefix}.api.mailchimp.com/3.0/lists/${listId}/members`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${Buffer.from(`anystring:${apiKey}`).toString("base64")}`,
      },
      body: JSON.stringify({
        email_address: email,
        status: "subscribed",
        tags: ["Perlini Waitlist"],
      }),
    }
  );

  if (!response.ok && response.status !== 200) {
    const data = await response.json();
    if (data.title === "Member Exists") {
      return { success: true, message: "Already subscribed" };
    }
    throw new Error(data.detail || "Mailchimp subscription failed");
  }

  return { success: true, message: "Subscribed via Mailchimp" };
}

export async function subscribeEmail(email: string): Promise<SubscribeResult> {
  const provider = (process.env.NEXT_PUBLIC_EMAIL_PROVIDER || "mailerlite") as EmailProvider;

  switch (provider) {
    case "convertkit":
      return subscribeConvertKit(email);
    case "mailchimp":
      return subscribeMailchimp(email);
    case "mailerlite":
    default:
      return subscribeMailerLite(email);
  }
}
