import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import WhyBuilding from "@/components/WhyBuilding";
import WhatYoullGet from "@/components/WhatYoullGet";
import About from "@/components/About";
import Waitlist from "@/components/Waitlist";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main>
      <Navigation />
      <Hero />
      <WhyBuilding />
      <WhatYoullGet />
      <About />
      <Waitlist />
      <Footer />
    </main>
  );
}
