import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy Policy — Perlini Consulting",
  description: "Privacy policy for Perlini Consulting",
  robots: { index: false, follow: false },
};

export default function Privacy() {
  return (
    <main className="min-h-screen py-24 px-6 md:px-12">
      <div className="max-w-2xl mx-auto">
        <Link
          href="/"
          className="font-sans text-[#D4AF6F] text-sm tracking-[0.1em] uppercase hover:opacity-70 transition-opacity mb-12 inline-block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF6F]"
        >
          ← Back
        </Link>

        <p className="font-sans text-[#D4AF6F] text-xs tracking-[0.3em] uppercase mb-4">Legal</p>
        <h1 className="font-serif text-4xl text-[#F5F0E6] mb-6">Privacy Policy</h1>
        <div className="w-12 h-px bg-[#D4AF6F] mb-10" />

        <div className="space-y-8 font-sans text-[#C5BCA8] text-base leading-[1.9]">
          <div>
            <p className="text-[#F5F0E6]/60 text-sm mb-4">Last updated: June 2026</p>
            <p>
              Perlini Consulting (&ldquo;we&rdquo;, &ldquo;us&rdquo;, &ldquo;our&rdquo;) respects
              your privacy and is committed to protecting your personal data.
            </p>
          </div>

          <section>
            <h2 className="font-serif text-xl text-[#F5F0E6] mb-3">What We Collect</h2>
            <p>
              When you join our waitlist, we collect your email address solely for the purpose of
              sending you updates about The Diplomacy Guide and related Perlini Consulting products.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-xl text-[#F5F0E6] mb-3">How We Use Your Data</h2>
            <p>
              Your email address is used only to communicate with you about Perlini Consulting
              products, updates, and relevant content. We do not sell, rent, or share your data
              with third parties for marketing purposes.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-xl text-[#F5F0E6] mb-3">Unsubscribing</h2>
            <p>
              You may unsubscribe from our mailing list at any time by clicking the unsubscribe
              link in any email we send, or by contacting us directly at{" "}
              <a
                href="mailto:hello@perlini.consulting"
                className="text-[#D4AF6F] hover:opacity-70 transition-opacity"
              >
                hello@perlini.consulting
              </a>
              .
            </p>
          </section>

          <section>
            <h2 className="font-serif text-xl text-[#F5F0E6] mb-3">Cookies & Analytics</h2>
            <p>
              We may use Google Analytics and Meta Pixel to understand how visitors interact with
              our website. These tools may set cookies. You can opt out via your browser settings
              or privacy tools.
            </p>
          </section>

          <section>
            <h2 className="font-serif text-xl text-[#F5F0E6] mb-3">Contact</h2>
            <p>
              For any privacy-related questions, contact us at{" "}
              <a
                href="mailto:hello@perlini.consulting"
                className="text-[#D4AF6F] hover:opacity-70 transition-opacity"
              >
                hello@perlini.consulting
              </a>
              .
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
