import type { Metadata } from "next";
import Script from "next/script";
import "./globals.css";

const GA_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID;
const META_PIXEL_ID = process.env.NEXT_PUBLIC_META_PIXEL_ID;

export const metadata: Metadata = {
  title: "Perlini Consulting — The Insider Roadmap to Diplomacy & International Careers",
  description:
    "Break into diplomacy, EU institutions, embassies, and international organizations. The Diplomacy Guide by Dera Perlini — written from inside a German embassy.",
  keywords: [
    "diplomacy careers",
    "EU institutions careers",
    "UN careers",
    "embassy internship",
    "international affairs",
    "international organizations",
    "diplomatic career guide",
    "Perlini Consulting",
  ],
  authors: [{ name: "Dera Perlini", url: "https://perlini.consulting" }],
  creator: "Dera Perlini",
  publisher: "Perlini Consulting",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://perlini.consulting",
    siteName: "Perlini Consulting",
    title: "Perlini Consulting — The Insider Roadmap to Diplomacy & International Careers",
    description:
      "Break into diplomacy, EU institutions, embassies, and international organizations. Written from inside a German embassy.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Perlini Consulting — The Diplomacy Guide",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Perlini Consulting — The Insider Roadmap to Diplomacy",
    description:
      "Break into diplomacy, EU institutions, embassies, and international organizations.",
    images: ["/og-image.jpg"],
    creator: "@DeraPerlini",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  metadataBase: new URL("https://perlini.consulting"),
  alternates: {
    canonical: "https://perlini.consulting",
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Perlini Consulting",
    url: "https://perlini.consulting",
    logo: "https://perlini.consulting/logo.png",
    description:
      "Perlini Consulting helps aspiring diplomats and international career professionals break into EU institutions, UN agencies, embassies, and related organizations.",
    founder: {
      "@type": "Person",
      name: "Dera Perlini",
      jobTitle: "Founder & International Career Consultant",
      sameAs: [
        "https://www.instagram.com/deraperlini",
        "https://www.linkedin.com/in/deraperlini",
      ],
    },
    sameAs: [
      "https://www.instagram.com/deraperlini",
      "https://www.linkedin.com/in/deraperlini",
    ],
  };

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
      </head>
      <body>
        {GA_ID && (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
              strategy="afterInteractive"
            />
            <Script id="ga4-init" strategy="afterInteractive">
              {`
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${GA_ID}', { page_path: window.location.pathname });
              `}
            </Script>
          </>
        )}
        {META_PIXEL_ID && (
          <Script id="meta-pixel" strategy="afterInteractive">
            {`
              !function(f,b,e,v,n,t,s)
              {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
              n.callMethod.apply(n,arguments):n.queue.push(arguments)};
              if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
              n.queue=[];t=b.createElement(e);t.async=!0;
              t.src=v;s=b.getElementsByTagName(e)[0];
              s.parentNode.insertBefore(t,s)}(window, document,'script',
              'https://connect.facebook.net/en_US/fbevents.js');
              fbq('init', '${META_PIXEL_ID}');
              fbq('track', 'PageView');
            `}
          </Script>
        )}
        {children}
      </body>
    </html>
  );
}
